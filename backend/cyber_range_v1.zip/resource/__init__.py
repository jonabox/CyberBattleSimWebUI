"""
All the API right now don't have the authorization model, which need to be added
"""